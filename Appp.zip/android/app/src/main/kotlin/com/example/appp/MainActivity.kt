package com.example.appp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
